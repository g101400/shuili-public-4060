/* 本地 AI 种子（含个人 OpenRouter Key，仅本机/私有构建使用，勿公开分享） */
window.AI_SEED = {
  apiKey: "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",
  default: "minimax-m27-free",
  strategy: { mode: "failover" }
};
